$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/resources/Features/TagsDemo.feature");
formatter.feature({
  "name": "Tags Demo",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@FunctionalTest"
    }
  ]
});
formatter.scenario({
  "name": "Sceanrio4",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@FunctionalTest"
    },
    {
      "name": "@SanityTest"
    }
  ]
});
formatter.step({
  "name": "This is sceanrio4",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepDefinition.TagsStepDefinition.this_is_sceanrio4()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Sceanrio5",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@FunctionalTest"
    }
  ]
});
formatter.step({
  "name": "This is sceanrio5",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepDefinition.TagsStepDefinition.this_is_sceanrio5()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Sceanrio6",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@FunctionalTest"
    }
  ]
});
formatter.step({
  "name": "This is sceanrio6",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepDefinition.TagsStepDefinition.this_is_sceanrio6()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Sceanrio7",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@FunctionalTest"
    }
  ]
});
formatter.step({
  "name": "This is sceanrio7",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepDefinition.TagsStepDefinition.this_is_sceanrio7()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Sceanrio8",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@FunctionalTest"
    }
  ]
});
formatter.step({
  "name": "This is sceanrio8",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepDefinition.TagsStepDefinition.this_is_sceanrio8()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Sceanrio9",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@FunctionalTest"
    }
  ]
});
formatter.step({
  "name": "This is sceanrio9",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepDefinition.TagsStepDefinition.this_is_sceanrio9()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Sceanrio10",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@FunctionalTest"
    }
  ]
});
formatter.step({
  "name": "This is sceanrio10",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepDefinition.TagsStepDefinition.this_is_sceanrio10()"
});
formatter.result({
  "status": "passed"
});
});